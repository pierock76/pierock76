/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package yafogesoj;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;
/**
 *
 * @author p
 */
public class dbMaster {
    /*
    DATI PER LA CONNESSIONE AL DB
    */
    private static final String urlconn="jdbc:mariadb://localhost:3306/stspos01";
    private static final String user   ="p";
    private static final String passwd ="profibus";
   
    
    /*
    RITORNA UN VETTORE DI STRINGHE CON TUTTI I VALORI DELLA TABELLA
    */
    public static Vector showD() throws ClassNotFoundException, SQLException {
       Connection con=DriverManager.getConnection(urlconn,user,passwd);
       Statement stmt=con.createStatement();
       ResultSet results=stmt.executeQuery("SELECT * FROM moduli;");
       Vector v=new Vector();
       while(results.next()){
           for (int i=1;i<26;i++)
            v.add(results.getString(i));
       
       }
    return v;
    }
    
    /*
    RITORNA UN VETTORE DI RIGHE PER LA TABELLA DI SELEZIONE
    */
     public static Vector recoverForTableD() throws ClassNotFoundException, SQLException {
       Connection con=DriverManager.getConnection(urlconn,user,passwd);
       Statement stmt=con.createStatement();
       ResultSet results=stmt.executeQuery("SELECT * FROM moduli ORDER BY id DESC;");
       Vector row=new Vector();
      
       while(results.next()){
           Vector col=new Vector();
           for (int i=1;i<=25;i++)
            col.add(results.getString(i));
          row.add(col);
       }
    
    return row;
    }
     
    /*
     RICERCA I DATI PER RIEMPIRE NUOVAMENTE IL FORM
     */
     public static Vector recoverForFormbyID(int id, YJFrame yjf) throws SQLException{
     String query="SELECT * FROM `moduli` WHERE `id`="+id+";";
     Connection con=DriverManager.getConnection(urlconn,user,passwd);
     Statement stmt=con.createStatement();
     ResultSet results=stmt.executeQuery(query);
     Vector row=new Vector();
     while(results.next()){
           Vector col=new Vector();
           for (int i=1;i<=25;i++)
            col.add(results.getString(i));
          row.add(col);
       }
    yjf.debugWriter("QUERY:"+query+"\n");
    yjf.debugWriter(row.toString());
    Vector t=(Vector)row.get(0);
    
    return t;
     
}
     
    public static void insertNewRecord(Vector v, YJFrame yjf) throws SQLException{
        
    String query="INSERT INTO stspos01.moduli(data, impianto, tensione, tipo_lavoro,"
            + "responsabile, preposto, ditta_preposto, manovratore, ditta_manovratore," 
            + "n_operatori, previsto_inizio,ora_previsto_inizio, previsto_fine,"
            + "ora_previsto_fine,imp_FTS, fasi_prepartaorie,"
            + "obiettivo_lavoro, elementi_oggetto_lavoro, rischi_ambientali,"
            + "elementi_in_sicurezza,misure_prevenzione, dpi, accesso_area, fasi_operative)"
            + "VALUES ("+gs(v)+");";
    yjf.debugWriter("\nINSERT QUERY:"+query);
  
      Connection con=DriverManager.getConnection(urlconn,user,passwd);
       Statement stmt=con.createStatement();
       stmt.executeUpdate(query);
       con.close();
   
    }
    
   public static void modificaRecord(Vector v,YJFrame yjf) throws SQLException {
     String query="UPDATE stspos01.moduli SET "
            +"data="+rv(v,1)
            +", impianto="+rv(v,2)
             + ", tensione="+rv(v,3)
             + ", tipo_lavoro="+rv(v,4)
            + ", responsabile="+rv(v,5)
             + ", preposto="+rv(v,6)
             + ", ditta_preposto="+rv(v,7)
             + ", manovratore="+rv(v,8)
             + ", ditta_manovratore="+rv(v,9)
            + ", n_operatori="+rv(v,10)
             + ", previsto_inizio="+rv(v,11)
             + ", ora_previsto_inizio="+rv(v,12)
             + ", previsto_fine="+rv(v,13)
            + ", ora_previsto_fine="+rv(v,14)
             + ", imp_FTS="+rv(v,15)
             + ", fasi_prepartaorie="+rv(v,16)
            + ", obiettivo_lavoro="+rv(v,17)
             + ", elementi_oggetto_lavoro="+rv(v,18)
             + ", rischi_ambientali="+rv(v,19)
            + ", elementi_in_sicurezza="+rv(v,15)
             +", misure_prevenzione="+rv(v,21)
             + ", dpi="+rv(v,22)
             + ", accesso_area="+rv(v,23)
             + ", fasi_operative="+rv(v,24)+
             " WHERE id="+rv(v,0)+";";
     yjf.debugWriter("\nUPDATE QUERY:"+query);
     System.out.println("*****\n"+query+"\n*****");
     Connection con=DriverManager.getConnection(urlconn,user,passwd);
       Statement stmt=con.createStatement();
       stmt.executeUpdate(query);
       con.close();
      
     
   }
    /**
     *
     * @param v
     * @return
     */
    private static String gs(Vector v){
        String output="NULL";
        int i=0;
        for (Object dato : v){
            String s=dato.toString();
            // occorre far diventare eventuali apici doppi apici '' se no sql si incacchia
            String purgata=s.replaceAll("'","''"); 
            if (i==0){;}
            else if (i==1){ output="\'"+purgata+"\'";}
            else {output=output+",\'"+purgata+"\'";}
            i++;
                
        }
       
        return output;
        
    }
    private static String rv(Vector v, int i){
        String output="NULL";
        String s=v.get(i).toString();
        // occorre far diventare eventuali apici doppi apici '' se no sql si incacchia
        String purgata=s.replaceAll("'","''"); 
        output="\'"+purgata+"\' ";
        return output;
    }
            
}

