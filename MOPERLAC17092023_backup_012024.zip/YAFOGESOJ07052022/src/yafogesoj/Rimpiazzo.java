/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package yafogesoj;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Vector;
import javax.swing.JFileChooser;

/**
 *
 * @author p
 */
public class Rimpiazzo {
    public static String pathfinder() throws IOException{
       
        JFileChooser fc = new JFileChooser();
        fc.showDialog(fc, "carica");
        File f=fc.getSelectedFile();
        String s=f.getAbsolutePath();
        s="IL PATH DEI FILE PER QUESTO SISTEMA È\n"+s;
        Rimpiazzo.scriviSuFile(s, "path_file_output.txt");
        return s;
    }
      
    private static void p(String s) {System.out.println(s);}
    /**
     * @param args the command line arguments
     */
    public static void swaptext(Vector v) throws FileNotFoundException, IOException {

       String directoryName = System.getProperty("user.dir");
		System.out.println("Current Working Directory is = " +directoryName);
       String filename=directoryName+"/src/yafogesoj/modello.html";
              filename="C:\\Users\\manele\\Documents\\NetBeansProjects\\YAFOGESOJ07052022\\src\\yafogesoj\\modello.html";
                System.out.println(filename);
       String out_filename=directoryName+"/src/yafogesoj/out.html";
              out_filename="C:\\Users\\manele\\Documents\\NetBeansProjects\\YAFOGESOJ07052022\\src\\yafogesoj\\out.html";
       
       BufferedReader reader = new BufferedReader(new FileReader(filename));
       var testo=new Vector();
       String riga=reader.readLine();
       while(riga!=null){ //testo.add(riga);
           
                testo.add(riga);
                riga=reader.readLine();
                
       }
       String daScrivere="";
       for (Object o: testo){
           /*
           *di seguito l'elenco dei rimpiazzi
           */
           String s;
           s=swappa(o,"###0###",v.get(0));
           s=swappa(s,  "###1###"  ,v.get(1));
           s=swappa(s,  "###2###"  ,v.get(2));
           s=swappa(s,  "###3###"  ,v.get(3));
           s=swappa(s,  "###4###"  ,v.get(4)); 
           s=swappa(s,  "###5###"  ,v.get(5));
           s=swappa(s,  "###6###"  ,v.get(6));
           s=swappa(s,  "###7###"  ,v.get(7));
           s=swappa(s,  "###8###"  ,v.get(8));
           s=swappa(s,  "###9###"  ,v.get(9));
           s=swappa(s,  "###10###"  ,v.get(10));
           s=swappa(s,  "###13###"  ,v.get(13));
           s=swappa(s,  "###15###"  ,v.get(15));
           s=swappa(s,  "###16###"  ,v.get(16));
           s=swappa(s,  "###17###"  ,v.get(17));
           s=swappa(s,  "###18###"  ,v.get(18));
           s=swappa(s,  "###19###"  ,v.get(19));
           s=swappa(s,  "###21###"  ,v.get(21));
           s=swappa(s,  "###22###"  ,v.get(22));
           s=swappa(s,  "###23###"  ,v.get(23));
           s=swappa(s,  "###24###"  ,v.get(24));
           
           
           daScrivere=daScrivere+"\n"+s;
       }
      
       scriviSuFile(daScrivere,out_filename);
      
    }    
    private static String swappa(Object s,String chiave,Object rimpiazzo){
        String t=(String)s;
        String k=chiave;
        String r=(String)rimpiazzo;
        return t.replaceAll(k, r);
    }    
    
    private static void scriviSuFile(String s,String nomefile) throws IOException{
        FileWriter w=new FileWriter(nomefile);
        BufferedWriter b=new BufferedWriter(w);
        b.write(s);
        b.flush();
        b.close();
        
    }
    }
    

