/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package yafogesoj;

import java.sql.SQLException;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;


/**
 *
 * @author p
 */
public class YAFOGESOJ {

    /**
     * @param args the command line arguments
     * @throws java.lang.ClassNotFoundException
     * @throws java.sql.SQLException
     */
    public static void main(String[] args) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
     
     // Rimpiazzo.prova();
      YJFrame my=new YJFrame();
      my.setTitle("MOPERLAC Rev 0.1 17092023 - piero.censi@pittini.it 334.6212208");
      my.setVisible(true);
      
      

      
    }
    
}
